"""
A set of wrappers around mautic marketing apis.
This includes wrappers around the core API
and additional functionality that we need that can call the apis.

"""
from .Mautic import Mautic

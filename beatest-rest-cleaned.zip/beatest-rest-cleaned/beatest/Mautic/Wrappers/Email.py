
class Email():
    pass

"""
This module provides a 1:1 mapping between python interface and Mautic's
Rest API.
"""
from .ContactsAPI import ContactsAPI

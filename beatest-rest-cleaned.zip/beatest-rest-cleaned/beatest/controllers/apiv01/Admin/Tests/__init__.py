from .Tests import admin_tests_controller

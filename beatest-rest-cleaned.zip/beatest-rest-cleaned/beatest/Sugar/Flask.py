"""
This module provides a scaffold for subclassing flask.

In the future, if extending flask is required, it can be done by
overriding functions in this class.
"""

from flask import Flask


class Flask(Flask):
    pass

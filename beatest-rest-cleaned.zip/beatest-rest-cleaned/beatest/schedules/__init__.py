def no_task():
    pass
